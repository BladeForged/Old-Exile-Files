#include "R3F_LOG_ENABLE.h"

#ifdef R3F_LOG_enable
#include "transporteur\dlg_contenu_vehicule.h"
#include "usine_creation\dlg_liste_objets.h"
#endif