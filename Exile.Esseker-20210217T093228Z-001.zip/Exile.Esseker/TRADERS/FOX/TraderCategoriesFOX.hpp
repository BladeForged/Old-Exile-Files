	class FOXCars
	{
		name = "FOX Cars";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Fox_ChallengerBR",
			"Fox_ChallengerDev",
			"Fox_ChallengerDev2",
			"Fox_ChallengerYB",
			"Fox_ChallengerO",
			"Fox_ChallengerW",
			"Fox_DaytonaStratos",
			"Fox_CobraR_police",
			"Fox_Outsider",
			"Fox_GNX",
			"Fox_Charger_Apocalypse",
			"Fox_Viper",
			"Fox_F40",
			"Fox_Patrol",
			"Fox_Interceptor",
			"Fox_DaytonaGeneral",
			"Fox_Daytona",
			"Fox_Patrol2",
			"Fox_Patrol3"
		};
	};

		class FOXTrucks
	{
		name = "FOX Trucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Fox_BUS",
			"Fox_Megabus",
			"Fox_Fireengine",
			"Fox_LandCruiser",
			"Fox_Tahoe_Apocalypse",
			"Fox_Pickup_Apocalypse",
			"Fox_Tahoe_Apocalypse",
			"Fox_Landrover",
			"Fox_Landrover2",
			"Fox_Pickup",
			"Fox_Pickup_Tow",
			"Fox_Pickup6S",
			"Fox_LandCruiserFox",
			"Fox_LandCruiser3",
			"Fox_LandCruiser2",
			"Fox_Truck"
		};
	};