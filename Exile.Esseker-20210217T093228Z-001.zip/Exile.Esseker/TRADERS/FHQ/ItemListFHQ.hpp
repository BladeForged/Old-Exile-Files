	///////////////////////////////////////////////////////////////////////////////
	// FHQACCESSORIES - by Poptart4050
	///////////////////////////////////////////////////////////////////////////////
	class FHQ_acc_ANPEQ15 							{ quality = 1; price = 300; };
	class FHQ_acc_ANPEQ15_black 					{ quality = 1; price = 300; };
	class FHQ_acc_LLM01F 							{ quality = 1; price = 300; };
	class FHQ_acc_LLM01L 							{ quality = 1; price = 300; };
	class FHQ_optic_AC11704 						{ quality = 1; price = 300; };
	class FHQ_optic_AC11704_tan 					{ quality = 1; price = 300; };
	class FHQ_optic_AC12136 						{ quality = 1; price = 300; };
	class FHQ_optic_AC12136_tan 					{ quality = 1; price = 300; };
	class FHQ_optic_ACOG 							{ quality = 1; price = 300; };
	class FHQ_optic_ACOG_tan 						{ quality = 1; price = 300; };
	class FHQ_optic_AIM_CompM4 						{ quality = 1; price = 300; };
	class FHQ_optic_AIM_tan 						{ quality = 1; price = 300; };
	class FHQ_optic_AimM_BLK 						{ quality = 1; price = 300; };
	class FHQ_optic_AimM_TAN 						{ quality = 1; price = 300; };
	class FHQ_optic_HWS 							{ quality = 1; price = 300; };
	class FHQ_optic_HWS_G33 						{ quality = 1; price = 300; };
	class FHQ_optic_HWS_G33_tan 					{ quality = 1; price = 300; };
	class FHQ_optic_HWS_tan 						{ quality = 1; price = 300; };
	class FHQ_optic_LeupoldERT 						{ quality = 1; price = 300; };
	class FHQ_optic_LeupoldERT_tan 					{ quality = 1; price = 300; };
	class FHQ_optic_MARS 							{ quality = 1; price = 300; };
	class FHQ_optic_MARS_tan 						{ quality = 1; price = 300; };
	class FHQ_optic_MCCO_M_BLK 						{ quality = 1; price = 300; };
	class FHQ_optic_MCCO_M_TAN                      { quality = 1; price = 300; };
	class FHQ_optic_MicroCCO 						{ quality = 1; price = 300; };
	class FHQ_optic_MicroCCO_low 					{ quality = 1; price = 300; };
	class FHQ_optic_MicroCCO_low_tan 				{ quality = 1; price = 300; };
	class FHQ_optic_MicroCCO_tan 					{ quality = 1; price = 300; };
	class FHQ_optic_TWS3050 						{ quality = 1; price = 300; };
	class FHQ_optic_VCOG 							{ quality = 1; price = 300; };
	class FHQ_optic_VCOG_tan 						{ quality = 1; price = 300; };