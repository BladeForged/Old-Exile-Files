/////////////////////////////////////////////////////////
	//Pook
	/////////////////////////////////////////////////////////
	class Pook	
	{
		name = "Pook M13";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"pook_H13_amphib",
			"pook_H13_civ",
			"pook_H13_civ_black",
			"pook_H13_civ_redwhite",
			"pook_H13_civ_slate",
			"pook_H13_civ_white",
			"pook_H13_civ_yellow",
			"pook_H13_gunship",
			"pook_H13_medevac",
			"pook_H13_transport"
		};
	};