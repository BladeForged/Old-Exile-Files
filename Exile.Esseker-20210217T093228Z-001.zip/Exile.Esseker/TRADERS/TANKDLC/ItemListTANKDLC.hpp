	///////////////////////////////////////////////////////////////////////////////
	//	tankDLC submitted by @ItsDutch
	///////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////
	//	RHINO
	///////////////////////////////////////////////////////////////////////////////
	class B_AFV_Wheeled_01_cannon_F			{ quality = 1; price = 2000000; };
	class B_AFV_Wheeled_01_up_cannon_F		{ quality = 1; price = 3000000; };
	class B_T_AFV_Wheeled_01_cannon_F		{ quality = 1; price = 2000000; };
	class B_T_AFV_Wheeled_01_up_cannon_F	{ quality = 1; price = 3000000; };

	///////////////////////////////////////////////////////////////////////////////
	//	awc
	///////////////////////////////////////////////////////////////////////////////
	class I_LT_01_AA_F						{ quality = 1; price = 600000; };
	class I_LT_01_AT_F						{ quality = 1; price = 600000; };
	class I_LT_01_cannon_F					{ quality = 1; price = 600000; };
	class I_LT_01_scout_F					{ quality = 1; price = 600000; };

	///////////////////////////////////////////////////////////////////////////////
	//	T140
	///////////////////////////////////////////////////////////////////////////////
	class O_MBT_04_cannon_F					{ quality = 1; price = 6000000; };
	class O_MBT_04_command_F				{ quality = 1; price = 6500000; };
	class O_T_MBT_04_cannon_F				{ quality = 1; price = 6000000; };
	class O_T_MBT_04_command_F				{ quality = 1; price = 6500000; };

	///////////////////////////////////////////////////////////////////////////////
	//	rocketvehicle
	///////////////////////////////////////////////////////////////////////////////
	class B_G_Offroad_01_AT_F				{ quality = 1; price = 250000; };
	class B_LSV_01_AT_F						{ quality = 1; price = 250000; };
	class B_T_LSV_01_AT_F					{ quality = 1; price = 250000; };
	class I_C_Offroad_02_AT_F				{ quality = 1; price = 250000; };
	class O_LSV_02_AT_F						{ quality = 1; price = 250000; };
	class O_T_LSV_02_AT_F					{ quality = 1; price = 250000; };

	///////////////////////////////////////////////////////////////////////////////
	//	tankdlcclothing
	///////////////////////////////////////////////////////////////////////////////
	class H_Tank_black_F					{ quality = 1; price = 5000; };
	class U_Tank_green_F					{ quality = 1; price = 10000; };
	
	///////////////////////////////////////////////////////////////////////////////	
	//	tankdlclaunchers
	///////////////////////////////////////////////////////////////////////////////	
	class launch_MRAWS_green_F				{ quality = 3; price = 7500; sellPrice = 1500; };
	class launch_MRAWS_green_rail_F			{ quality = 3; price = 7500; sellPrice = 1500; };
	class launch_MRAWS_olive_F				{ quality = 3; price = 7500; sellPrice = 1500; };
	class launch_MRAWS_olive_rail_F			{ quality = 3; price = 7500; sellPrice = 1500; };
	class launch_MRAWS_sand_F				{ quality = 3; price = 7500; sellPrice = 1500; };
	class launch_MRAWS_sand_rail_F			{ quality = 3; price = 7500; sellPrice = 1500; };

	///////////////////////////////////////////////////////////////////////////////	
	//	tankdlclauncherammo
	///////////////////////////////////////////////////////////////////////////////	
	class MRAWS_HEAT_F						{ quality = 1; price = 3000; };
	class MRAWS_HE_F 						{ quality = 1; price = 3000; };