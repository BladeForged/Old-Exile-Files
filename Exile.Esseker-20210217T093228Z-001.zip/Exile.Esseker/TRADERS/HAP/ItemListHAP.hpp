//////////////////////////////////////////////////////////////////////////////////
	// HAP Cars/Clothings/Weapons/Vehicles [CiC]red_ned http://cic-gaming.co.uk
	// Thanks to XxFri3ndlyxX for providing these files
	//////////////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////////////
	// HAP CLOTHES
	//////////////////////////////////////////////////////////////////////////////////
	class HAP_BTN_army							{ quality = 1; price = 40; };
	class HAP_BTN_haw1							{ quality = 1; price = 40; };
	class HAP_BTN_haw2							{ quality = 1; price = 40; };
	class HAP_BTN_hp1 							{ quality = 1; price = 40; };
	class HAP_BTN_pld_blu1						{ quality = 1; price = 40; };
	class HAP_BTN_pld_blu2						{ quality = 1; price = 40; };
	class HAP_BTN_pld_orng1 					{ quality = 1; price = 40; };
	class HAP_BTN_pld_red1						{ quality = 1; price = 40; };
	class HAP_BTN_prp1							{ quality = 1; price = 40; };
	class HAP_CIV2_basic						{ quality = 1; price = 40; };
	class HAP_CIV2_ob_striped 					{ quality = 1; price = 40; };
	class HAP_CIV3_basic						{ quality = 1; price = 40; };
	class HAP_CIV3_blue 						{ quality = 1; price = 40; };
	class HAP_CIV3_camo1						{ quality = 1; price = 40; };
	class HAP_CIV3_green						{ quality = 1; price = 40; };
	class HAP_CIV3_redPlaid 					{ quality = 1; price = 40; };
	class HAP_CIV3_snow1						{ quality = 1; price = 40; };
	class HAP_CIV4_basic						{ quality = 1; price = 40; };
	class HAP_CIV5_basic						{ quality = 1; price = 40; };
	class HAP_CIV5_brown						{ quality = 1; price = 40; };
	class HAP_CIV5_snow1						{ quality = 1; price = 40; };
	class HAP_CIV5_soft_blue					{ quality = 1; price = 40; };
	class HAP_FAT_black1						{ quality = 1; price = 60; };
	class HAP_FAT_blu1							{ quality = 1; price = 60; };
	class HAP_FAT_dea 							{ quality = 1; price = 60; };
	class HAP_FAT_orn1							{ quality = 1; price = 60; };
	class HAP_FAT_ref 							{ quality = 1; price = 60; };
	class HAP_FAT_snow							{ quality = 1; price = 60; };
	class HAP_GUE_pun 							{ quality = 1; price = 40; };
	class HAP_OF1_WOOD_CombatUniform 			{ quality = 1; price = 250; };
	class HAP_OF1_snow_CombatUniform			{ quality = 1; price = 250; };
	class HAP_PARA_basic						{ quality = 1; price = 40; };
	class HAP_PARA_blue 						{ quality = 1; price = 40; };
	class HAP_PARA_camo1						{ quality = 1; price = 40; };
	class HAP_PARA_camo2						{ quality = 1; price = 40; };
	class HAP_PARA_camo3						{ quality = 1; price = 40; };
	class HAP_PARA_camo4						{ quality = 1; price = 40; };
	class HAP_POLO_blackNwinter 				{ quality = 1; price = 40; };
	class HAP_POLO_blackNwood 					{ quality = 1; price = 40; };
	class HAP_POLO_bowler1						{ quality = 1; price = 40; };
	class HAP_POLO_bowler2						{ quality = 1; price = 40; };
	class HAP_POLO_bowler3						{ quality = 1; price = 40; };
	class HAP_POLO_cbrown 						{ quality = 1; price = 40; };
	class HAP_POLO_hello						{ quality = 1; price = 40; };
	class HAP_POLO_sox							{ quality = 1; price = 40; };
	class HAP_POLO_yank 						{ quality = 1; price = 40; };
	class HAP_SNIPER_black						{ quality = 1; price = 1000; };
	class HAP_SNIPER_top_skull1 				{ quality = 1; price = 1000; };
	class HAP_TEE2_Gcamo1 						{ quality = 1; price = 40; };
	class HAP_TEE2_Gcamo2 						{ quality = 1; price = 40; };
	class HAP_TEE2_HUNTER_1_1 					{ quality = 1; price = 40; };
	class HAP_TEE2_HUNTER_1_2 					{ quality = 1; price = 40; };
	class HAP_TEE2_HUNTER_1_3 					{ quality = 1; price = 40; };
	class HAP_TEE2_HUNTER_1_4 					{ quality = 1; price = 40; };
	class HAP_TEE2_HUNTER_1_5 					{ quality = 1; price = 40; };
	class HAP_TEE2_HUNTER_1_6 					{ quality = 1; price = 40; };
	class HAP_TEE2_black						{ quality = 1; price = 40; };
	class HAP_TEE2_bloody 						{ quality = 1; price = 40; };
	class HAP_TEE2_greygrn						{ quality = 1; price = 40; };
	class HAP_TEE2_prpl 						{ quality = 1; price = 40; };
	class HAP_TEE2_tiedye 						{ quality = 1; price = 40; };
	class HAP_TEE_HUNTER_2_1					{ quality = 1; price = 40; };
	class HAP_TEE_HUNTER_2_2					{ quality = 1; price = 40; };
	class HAP_TEE_HUNTER_2_3					{ quality = 1; price = 40; };
	class HAP_TEE_HUNTER_2_4					{ quality = 1; price = 40; };
	class HAP_TEE_HUNTER_2_5					{ quality = 1; price = 40; };
	class HAP_TEE_HUNTER_2_6					{ quality = 1; price = 40; };
	class HAP_TEE_boston						{ quality = 1; price = 40; };
	class HAP_TEE_hobo							{ quality = 1; price = 40; };
	class HAP_TEE_maxx							{ quality = 1; price = 40; };
	class HAP_TEE_mooby 						{ quality = 1; price = 40; };
	class HAP_TEE_orngNblu						{ quality = 1; price = 40; };
	class HAP_TEE_tiedye						{ quality = 1; price = 40; };
	class HAP_TEE_tricamo1						{ quality = 1; price = 40; };
	class HAP_TEE_vault 						{ quality = 1; price = 40; };
	class HAP_TEE_yellowNgrn					{ quality = 1; price = 40; };

	///////////////////////////////////////////////////////////////////////////////////
	// HAP BACKPACK
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_B_Bergen_blue						{ quality = 1; price = 280; };
	class HAP_B_Bergen_camo_blue 				{ quality = 1; price = 280; };
	class HAP_B_Bergen_gooch 					{ quality = 1; price = 280; };
	class HAP_B_Bergen_ice_camo_black			{ quality = 1; price = 280; };
	class HAP_B_Bergen_red 						{ quality = 1; price = 280; };
	class HAP_B_Bergen_stars 					{ quality = 1; price = 280; };
	class HAP_B_Bergen_weed_1					{ quality = 1; price = 280; };
	class HAP_B_Bergen_weed_2					{ quality = 1; price = 280; };
	class HAP_B_Bergen_white 					{ quality = 1; price = 280; };
	class HAP_B_Bergen_woodland					{ quality = 1; price = 280; };
	class HAP_B_Bergen_woodland_2				{ quality = 1; price = 280; };
	class HAP_B_Carryall_CRAFTBAG				{ quality = 1; price = 2500; };
	class HAP_B_Carryall_black 					{ quality = 1; price = 600; };
	class HAP_B_Carryall_desert					{ quality = 1; price = 320; };
	class HAP_B_Carryall_grnNbrwn				{ quality = 1; price = 320; };
	class HAP_B_Carryall_hazmat					{ quality = 1; price = 500; };
	class HAP_B_Carryall_orngNwhite				{ quality = 1; price = 500; };
	class HAP_B_Carryall_tiedye					{ quality = 1; price = 320; };
	class HAP_B_Carryall_whiteNgry 				{ quality = 1; price = 320; };
	class HAP_B_Carryall_woodNblu				{ quality = 1; price = 320; };
	class HAP_B_Carryall_woodland				{ quality = 1; price = 320; };
	class HAP_B_Gorod_blue 						{ quality = 1; price = 280; };
	class HAP_B_Gorod_explorer 					{ quality = 1; price = 500; };
	class HAP_B_Gorod_floral_black 				{ quality = 1; price = 280; };
	class HAP_B_Gorod_green						{ quality = 1; price = 280; };
	class HAP_B_Gorod_ice_camo_1 				{ quality = 1; price = 280; };
	class HAP_B_Gorod_orange 					{ quality = 1; price = 280; };
	class HAP_B_Gorod_white						{ quality = 1; price = 280; };
	class HAP_B_Gorod_winter_1 					{ quality = 1; price = 280; };

	///////////////////////////////////////////////////////////////////////////////////
	// VESTS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_VEST_KERRY_black 					{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_blue					{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_brown 					{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_camo1_orange			{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_camo2_whitegreen		{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_camo2_woodland			{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_camo3_woodland			{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_red 					{ quality = 1; price = 500; };
	class HAP_VEST_KERRY_white 					{ quality = 1; price = 500; };
	class HAP_VEST_PRESS_blue					{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo1_blue				{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo1_wood1 			{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo2_orange			{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo2_red 				{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo2_urban1			{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo2_winter1 			{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo3_blue				{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_camo3_wood1 			{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_green 					{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_herb1 					{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_jolly_roger 			{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_orange					{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_pink					{ quality = 1; price = 90; };
	class HAP_VEST_PRESS_red 					{ quality = 1; price = 90; };
	class HAP_VEST_TAC_HUNTER_1					{ quality = 1; price = 200; };
	class HAP_VEST_TAC_HUNTER_2					{ quality = 1; price = 200; };
	class HAP_VEST_TAC_HUNTER_3					{ quality = 1; price = 200; };
	class HAP_VEST_TAC_HUNTER_4					{ quality = 1; price = 200; };
	class HAP_VEST_TAC_HUNTER_5					{ quality = 1; price = 200; };
	class HAP_press_vest_swat					{ quality = 1; price = 90; };
	class HAP_press_vest_tiger 					{ quality = 1; price = 90; };
	class HAP_press_vest_winter1 				{ quality = 1; price = 90; };
	class HAP_press_vest_winter2 				{ quality = 1; price = 90; };

	///////////////////////////////////////////////////////////////////////////////////
	// MARKSMEN VESTS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_V_PlateCarrierGL_SOA 				{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_blue				{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_brown 			{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_camo1 			{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_camo2 			{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_camo3 			{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_camo4 			{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_green 			{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_leo1				{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_red 				{ quality = 1; price = 500; };
	class HAP_V_PlateCarrierGL_tiger 			{ quality = 1; price = 500; };

	///////////////////////////////////////////////////////////////////////////////////
	// HELMETS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_HPILOT_big_smile1					{ quality = 1; price = 200; };
	class HAP_HPILOT_green 						{ quality = 1; price = 200; };
	class HAP_HPILOT_hex_camo1 					{ quality = 1; price = 200; };
	class HAP_HPILOT_hex_camo2 					{ quality = 1; price = 200; };
	class HAP_HPILOT_hex_camo3 					{ quality = 1; price = 200; };
	class HAP_HPILOT_orange						{ quality = 1; price = 200; };
	class HAP_HPILOT_predator					{ quality = 1; price = 200; };
	class HAP_HPILOT_robot1						{ quality = 1; price = 200; };
	class HAP_HPILOT_rough_teeth1				{ quality = 1; price = 200; };
	class HAP_HPILOT_smile 						{ quality = 1; price = 200; };
	class HAP_HPILOT_smile2						{ quality = 1; price = 200; };
	class HAP_HPILOT_teal						{ quality = 1; price = 200; };
	class HAP_MOTO_BLACK 						{ quality = 1; price = 150; };
	class HAP_MOTO_BLACKNRED 					{ quality = 1; price = 150; };
	class HAP_MOTO_DASH							{ quality = 1; price = 150; };
	class HAP_MOTO_FLAME1						{ quality = 1; price = 150; };
	class HAP_MOTO_GREEN 						{ quality = 1; price = 150; };
	class HAP_MOTO_PAT 							{ quality = 1; price = 150; };
	class HAP_MOTO_PINK							{ quality = 1; price = 150; };
	class HAP_MOTO_PLUM							{ quality = 1; price = 150; };
	class HAP_MOTO_STUNT 						{ quality = 1; price = 150; };

	///////////////////////////////////////////////////////////////////////////////////
	// ASSAULT RIFFLE
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_MX_camo1_green 					{ quality = 1; price = 450; };
	class HAP_MX_camo1_purple					{ quality = 1; price = 450; };
	class HAP_MX_camo1_yellow					{ quality = 1; price = 450; };
	class HAP_MX_green 							{ quality = 1; price = 450; };
	class HAP_MX_hex_beige 						{ quality = 1; price = 450; };
	class HAP_MX_hex_blue						{ quality = 1; price = 450; };
	class HAP_MX_hex_green 						{ quality = 1; price = 450; };
	class HAP_MX_pink							{ quality = 1; price = 450; };
	class HAP_MX_red 							{ quality = 1; price = 450; };
	class HAP_MX_teal							{ quality = 1; price = 450; };
	class HAP_MX_yellow							{ quality = 1; price = 450; };

	///////////////////////////////////////////////////////////////////////////////////
	// SNIPERS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_CHEY_camo2_blue					{ quality = 1; price = 850; };
	class HAP_CHEY_camo2_woodland				{ quality = 1; price = 850; };
	class HAP_CHEY_camo3_black 					{ quality = 1; price = 850; };
	class HAP_CHEY_camo3_green 					{ quality = 1; price = 850; };
	class HAP_CHEY_camo3_pink					{ quality = 1; price = 850; };
	class HAP_CHEY_leo1							{ quality = 1; price = 850; };
	class HAP_CHEY_teal							{ quality = 1; price = 850; };
	class HAP_CHEY_white 						{ quality = 1; price = 850; };
	class HAP_CHEY_woodland1 					{ quality = 1; price = 850; };
	class HAP_CHEY_woodland1_green 				{ quality = 1; price = 850; };
	class HAP_CHEY_woodland1_orange				{ quality = 1; price = 850; };
	class HAP_DMR_black							{ quality = 1; price = 600; };
	class HAP_DMR_camoORN						{ quality = 1; price = 600; };
	class HAP_DMR_digiGRN						{ quality = 1; price = 600; };
	class HAP_DMR_leo							{ quality = 1; price = 600; };
	class HAP_DMR_leoA 							{ quality = 1; price = 600; };
	class HAP_DMR_snow 							{ quality = 1; price = 600; };
	class HAP_DMR_zebra							{ quality = 1; price = 600; };
	class HAP_EBR_black							{ quality = 1; price = 700; };
	class HAP_EBR_desert 						{ quality = 1; price = 700; };
	class HAP_EBR_desertA						{ quality = 1; price = 700; };
	class HAP_EBR_snow 							{ quality = 1; price = 700; };
	class HAP_EBR_wavesblu 						{ quality = 1; price = 700; };
	class HAP_LYNX_camo1_blue					{ quality = 1; price = 900; };
	class HAP_LYNX_camo1_green 					{ quality = 1; price = 900; };
	class HAP_LYNX_camo1_tan 					{ quality = 1; price = 900; };
	class HAP_LYNX_green 						{ quality = 1; price = 900; };
	class HAP_LYNX_hex_beige 					{ quality = 1; price = 900; };
	class HAP_LYNX_hex_blue						{ quality = 1; price = 900; };
	class HAP_LYNX_orange						{ quality = 1; price = 900; };
	class HAP_LYNX_red 							{ quality = 1; price = 900; };
	class HAP_LYNX_white 						{ quality = 1; price = 900; };
	class HAP_LYNX_yellow						{ quality = 1; price = 900; };

	///////////////////////////////////////////////////////////////////////////////////
	// MARKSMEN SNIPERS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_MARKS_ASP_blue 					{ quality = 1; price = 700; };
	class HAP_MARKS_ASP_blueCamo 				{ quality = 1; price = 700; };
	class HAP_MARKS_ASP_orangeCamo 				{ quality = 1; price = 700; };
	class HAP_MARKS_ASP_snow 					{ quality = 1; price = 700; };
	class HAP_MARKS_ASP_unicornPuke				{ quality = 1; price = 700; };
	class HAP_MARKS_ASP_white					{ quality = 1; price = 700; };
	class HAP_MARKS_CYRUS_brightRed				{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_camo1					{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_camo2					{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_eyesOn1				{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_herb1					{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_herb2					{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_herb3					{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_limeGreen				{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_orange1				{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_red1 					{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_skulls1				{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_skullsRed1 			{ quality = 1; price = 850; };
	class HAP_MARKS_CYRUS_zebra1 				{ quality = 1; price = 850; };
	class HAP_MARKS_DMR_02_camo1 				{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_camo2 				{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_camo3 				{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_herb1 				{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_herb2 				{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_herb3 				{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_rainbowsunshine1		{ quality = 1; price = 800; };
	class HAP_MARKS_DMR_02_squared1				{ quality = 1; price = 800; };
	class HAP_MARKS_EMR_camo1					{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_camo2					{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_purple1					{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_rainbow1 				{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_red1 					{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_teal1					{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_white1 					{ quality = 1; price = 750; };
	class HAP_MARKS_EMR_whiteCamo1 				{ quality = 1; price = 750; };
	class HAP_MARKS_M14_camo1					{ quality = 1; price = 800; };
	class HAP_MARKS_M14_camo2					{ quality = 1; price = 800; };
	class HAP_MARKS_M14_camo3					{ quality = 1; price = 800; };
	class HAP_MARKS_M14_flames1					{ quality = 1; price = 800; };
	class HAP_MARKS_M14_white					{ quality = 1; price = 800; };
	class HAP_MARKS_M14_wood1					{ quality = 1; price = 800; };

	///////////////////////////////////////////////////////////////////////////////////
	//-- VEHICLES --
	//////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////////
	// ATV
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_ATV_new_black						{ quality = 1; price = 2500; };
	class HAP_ATV_new_blue 						{ quality = 1; price = 2500; };
	class HAP_ATV_new_green						{ quality = 1; price = 2500; };
	class HAP_ATV_new_yellow 					{ quality = 1; price = 2500; };
	class HAP_ATV_old_blue 						{ quality = 1; price = 2500; };
	class HAP_ATV_old_green						{ quality = 1; price = 2500; };
	class HAP_ATV_old_red						{ quality = 1; price = 2500; };
	class HAP_ATV_old_teal 						{ quality = 1; price = 2500; };

	///////////////////////////////////////////////////////////////////////////////////
	// SUV
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_SUV_bmw1 							{ quality = 1; price = 25000; };
	class HAP_SUV_cop_black						{ quality = 1; price = 35000; };
	class HAP_SUV_cop_blue 						{ quality = 1; price = 35000; };
	class HAP_SUV_medic							{ quality = 1; price = 55000; };

	///////////////////////////////////////////////////////////////////////////////////
	// SUV ARMA II
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_SUV_blue 							{ quality = 1; price = 20000; };
	class HAP_SUV_red							{ quality = 1; price = 20000; };


	///////////////////////////////////////////////////////////////////////////////////
	// OFFROADS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_OFFRD_HUNTR_1						{ quality = 1; price = 16000; };
	class HAP_OFFRD_HUNTR_2						{ quality = 1; price = 16000; };
	class HAP_OFFRD_autumn 						{ quality = 1; price = 16000; };
	class HAP_OFFRD_bandit 						{ quality = 1; price = 16000; };
	class HAP_OFFRD_banhammer					{ quality = 1; price = 16000; };
	class HAP_OFFRD_digi_BW						{ quality = 1; price = 16000; };
	class HAP_OFFRD_digi_red 					{ quality = 1; price = 16000; };
	class HAP_OFFRD_exilelogo					{ quality = 1; price = 16000; };
	class HAP_OFFRD_generallee 					{ quality = 1; price = 16000; };
	class HAP_OFFRD_hemi 						{ quality = 1; price = 16000; };
	class HAP_OFFRD_hobo 						{ quality = 1; price = 16000; };
	class HAP_OFFRD_hobo1						{ quality = 1; price = 16000; };
	class HAP_OFFRD_kitty						{ quality = 1; price = 16000; };
	class HAP_OFFRD_larry						{ quality = 1; price = 16000; };
	class HAP_OFFRD_police1						{ quality = 1; price = 25000; };
	class HAP_OFFRD_racer_BW 					{ quality = 1; price = 16000; };
	class HAP_OFFRD_racer_RW 					{ quality = 1; price = 16000; };
	class HAP_OFFRD_rustbucket1					{ quality = 1; price = 16000; };
	class HAP_OFFRD_rustbucket2					{ quality = 1; price = 16000; };
	class HAP_OFFRD_rustbucket3					{ quality = 1; price = 16000; };
	class HAP_OFFRD_rustbucket_racer1			{ quality = 1; price = 16000; };
	class HAP_OFFRD_woodland 					{ quality = 1; price = 16000; };


	///////////////////////////////////////////////////////////////////////////////////
	// STRIDERS
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_STRY_HUNTR_1 						{ quality = 1; price = 44000; };
	class HAP_STRY_desert1 						{ quality = 1; price = 44000; };
	class HAP_STRY_green1						{ quality = 1; price = 44000; };
	class HAP_STRY_urban1						{ quality = 1; price = 44000; };
	class HAP_STRY_woodland1 					{ quality = 1; price = 44000; };

	///////////////////////////////////////////////////////////////////////////////////
	// MRAP
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_MRAP_HUNTRS_1						{ quality = 1; price = 44000; };
	class HAP_MRAP_blue_1						{ quality = 1; price = 44000; };
	class HAP_MRAP_bomber_1						{ quality = 1; price = 44000; };
	class HAP_MRAP_green_1 						{ quality = 1; price = 44000; };
	class HAP_MRAP_hobo_1						{ quality = 1; price = 44000; };
	class HAP_MRAP_orange_1						{ quality = 1; price = 44000; };
	class HAP_MRAP_red_1 						{ quality = 1; price = 44000; };
	class HAP_MRAP_snake_1 						{ quality = 1; price = 44000; };
	class HAP_MRAP_winter_1						{ quality = 1; price = 44000; };

	///////////////////////////////////////////////////////////////////////////////////
	// IFRIT
	///////////////////////////////////////////////////////////////////////////////////
	class HAP_IF_blue_1							{ quality = 1; price = 23000; };
	class HAP_IF_green_1 						{ quality = 1; price = 23000; };
	class HAP_IF_orange_1						{ quality = 1; price = 23000; };
	class HAP_IF_pink_1							{ quality = 1; price = 23000; };
	class HAP_IF_pirate_1						{ quality = 1; price = 23000; };
	class HAP_IF_purple_1						{ quality = 1; price = 23000; };
	class HAP_IF_red_1 							{ quality = 1; price = 23000; };
	class HAP_IF_snake_1 						{ quality = 1; price = 23000; };
	class HAP_IF_soa_black_1 					{ quality = 1; price = 23000; };
	class HAP_IF_winter_1						{ quality = 1; price = 23000; };
	class HAP_IF_woodland_1						{ quality = 1; price = 23000; };