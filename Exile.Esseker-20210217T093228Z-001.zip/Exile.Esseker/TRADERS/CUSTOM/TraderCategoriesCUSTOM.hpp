	class CBuilding
	{
		name = "Building Supplies";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Item_ConcreteDoorwayKit",
			"Exile_Item_ConcreteDrawBridgeKit",
			"Exile_Item_ConcreteFloorKit",
			"Exile_Item_ConcreteFloorPortKit",
			"Exile_Item_ConcreteFloorPortSmallKit",
			"Exile_Item_ConcreteGateKit",
			"Exile_Item_ConcreteLadderHatchKit",
			"Exile_Item_ConcreteStairsKit",
			"Exile_Item_ConcreteSupportKit",
			"Exile_Item_ConcreteWallKit",
			"Exile_Item_MetalHedgehogKit",
			"Exile_Item_MetalLadderDoubleKit",
			"Exile_Item_MetalLadderKit",
			"Exile_Item_OldChestKit",
			"Exile_Item_WoodDoorKit",
			"Exile_Item_WoodDoorwayKit",
			"Exile_Item_WoodFloorKit",
			"Exile_Item_WoodFloorPortKit",
			"Exile_Item_WoodGateKit",
			"Exile_Item_WoodLadderHatchKit",
			"Exile_Item_WoodStairsKit",
			"Exile_Item_WoodSupportKit",
			"Exile_Item_WoodWallHalfKit",
			"Exile_Item_WoodWallKit",
			"Exile_Item_WoodWindowKit",
			"Exile_Item_WorkBenchKit"
		};
	};

	class CPlanes
	{
		name = "Custom Planes";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			// moved to arma3
		};
	};