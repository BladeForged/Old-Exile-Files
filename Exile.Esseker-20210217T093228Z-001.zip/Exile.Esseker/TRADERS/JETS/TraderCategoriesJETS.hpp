class JetItems
{
	name = "JET Items";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
	items[] =
	{
		"V_DeckCrew_blue_F",
		"V_DeckCrew_brown_F",
		"V_DeckCrew_green_F",
		"V_DeckCrew_red_F",
		"V_DeckCrew_violet_F",
		"V_DeckCrew_white_F",
		"V_DeckCrew_yellow_F"
	};
};

class JetPlanes
{
	name = "JET Planes";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"I_Plane_Fighter_04_F",
		"B_Plane_Fighter_01_Stealth_F",
		"B_Plane_Fighter_01_F",
		"O_Plane_Fighter_02_F",
		"O_Plane_Fighter_02_Stealth_F"
	};
};