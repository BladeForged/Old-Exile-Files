	///////////////////////////////////////////////////////////////////////////////
	//CUPVEHICLES
	///////////////////////////////////////////////////////////////////////////////
	//CUPUnarmed
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_HMMWV_Ambulance_ACR					{ quality = 1; price = 13000; };
	class CUP_B_HMMWV_Ambulance_USA					{ quality = 1; price = 13000; };
	class CUP_B_HMMWV_Ambulance_USMC				{ quality = 1; price = 13000; };
	class CUP_B_HMMWV_Transport_USA					{ quality = 1; price = 13000; };
	class CUP_B_HMMWV_Unarmed_USA					{ quality = 1; price = 13000; };
	class CUP_B_HMMWV_Unarmed_USMC					{ quality = 1; price = 13000; };
	class CUP_B_LR_Ambulance_CZ_D					{ quality = 1; price = 12800; };
	class CUP_B_LR_Ambulance_CZ_W					{ quality = 1; price = 12800; };
	class CUP_B_LR_Ambulance_GB_D					{ quality = 1; price = 12800; };
	class CUP_B_LR_Ambulance_GB_W					{ quality = 1; price = 12800; };
	class CUP_B_LR_Transport_CZ_D					{ quality = 1; price = 12800; };
	class CUP_B_LR_Transport_CZ_W					{ quality = 1; price = 12800; };
	class CUP_B_LR_Transport_GB_D					{ quality = 1; price = 12800; };
	class CUP_B_LR_Transport_GB_W					{ quality = 1; price = 12800; };
	class CUP_B_UAZ_Open_ACR						{ quality = 1; price = 12500; };
	class CUP_B_UAZ_Open_CDF						{ quality = 1; price = 12500; };
	class CUP_B_UAZ_Unarmed_ACR						{ quality = 1; price = 12500; };
	class CUP_B_UAZ_Unarmed_CDF						{ quality = 1; price = 12500; };
	class CUP_B_Ural_CDF							{ quality = 1; price = 12500; };
	class CUP_B_Ural_Empty_CDF						{ quality = 1; price = 12500; };
	class CUP_B_Ural_Open_CDF						{ quality = 1; price = 12500; };
	class CUP_B_Ural_Refuel_CDF						{ quality = 1; price = 15500; };
	class CUP_B_Ural_Repair_CDF						{ quality = 1; price = 13000; };
	class CUP_C_Datsun								{ quality = 1; price = 12000; };
	class CUP_C_Datsun_4seat						{ quality = 1; price = 12000; };
	class CUP_C_Datsun_Covered						{ quality = 1; price = 12000; };
	class CUP_C_Datsun_Plain						{ quality = 1; price = 12000; };
	class CUP_C_Datsun_Tubeframe					{ quality = 1; price = 12000; };
	class CUP_C_LR_Transport_CTK					{ quality = 1; price = 12800; };
	class CUP_C_UAZ_Open_TK_CIV						{ quality = 1; price = 12500; };
	class CUP_C_UAZ_Unarmed_TK_CIV					{ quality = 1; price = 12500; };
	class CUP_C_Ural_Civ_01							{ quality = 1; price = 12500; };
	class CUP_C_Ural_Civ_02							{ quality = 1; price = 12500; };
	class CUP_C_Ural_Civ_03							{ quality = 1; price = 12500; };
	class CUP_C_Ural_Open_Civ_01					{ quality = 1; price = 12500; };
	class CUP_C_Ural_Open_Civ_02					{ quality = 1; price = 12500; };
	class CUP_C_Ural_Open_Civ_03					{ quality = 1; price = 12500; };
	class CUP_I_M113_Med_RACS						{ quality = 1; price = 14500; };
	class CUP_I_M113_Med_UN							{ quality = 1; price = 14500; };
	class CUP_I_UAZ_Open_UN							{ quality = 1; price = 12500; };
	class CUP_I_UAZ_Unarmed_UN						{ quality = 1; price = 12500; };
	class CUP_I_Ural_Empty_UN						{ quality = 1; price = 12500; };
	class CUP_I_Ural_Repair_UN						{ quality = 1; price = 13000; };
	class CUP_I_Ural_UN								{ quality = 1; price = 12500; };
	class CUP_O_LR_Ambulance_TKA					{ quality = 1; price = 12800; };
	class CUP_O_LR_Transport_TKA					{ quality = 1; price = 12800; };
	class CUP_O_LR_Transport_TKM					{ quality = 1; price = 12800; };
	class CUP_O_UAZ_Open_CHDKZ						{ quality = 1; price = 12500; };
	class CUP_O_UAZ_Open_RU							{ quality = 1; price = 12500; };
	class CUP_O_UAZ_Open_TKA						{ quality = 1; price = 12500; };
	class CUP_O_UAZ_Unarmed_CHDKZ					{ quality = 1; price = 12500; };
	class CUP_O_UAZ_Unarmed_RU						{ quality = 1; price = 12500; };
	class CUP_O_UAZ_Unarmed_TKA						{ quality = 1; price = 12500; };
	class CUP_O_Ural_CHDKZ							{ quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_CHDKZ					{ quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_RU						{ quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_SLA						{ quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_TKA						{ quality = 1; price = 12500; };
	class CUP_O_Ural_Open_CHDKZ						{ quality = 1; price = 12500; };
	class CUP_O_Ural_Open_RU						{ quality = 1; price = 12500; };
	class CUP_O_Ural_Open_SLA						{ quality = 1; price = 12500; };
	class CUP_O_Ural_Open_TKA						{ quality = 1; price = 12500; };
	class CUP_O_Ural_RU								{ quality = 1; price = 12500; };
	class CUP_O_Ural_Refuel_CHDKZ					{ quality = 1; price = 15500; };
	class CUP_O_Ural_Refuel_RU						{ quality = 1; price = 15500; };
	class CUP_O_Ural_Refuel_SLA						{ quality = 1; price = 15500; };
	class CUP_O_Ural_Refuel_TKA						{ quality = 1; price = 15500; };
	class CUP_O_Ural_Repair_CHDKZ					{ quality = 1; price = 13000; };
	class CUP_O_Ural_Repair_RU						{ quality = 1; price = 13000; };
	class CUP_O_Ural_Repair_SLA						{ quality = 1; price = 13000; };
	class CUP_O_Ural_Repair_TKA						{ quality = 1; price = 13000; };
	class CUP_O_Ural_SLA							{ quality = 1; price = 12500; };
	class CUP_O_Ural_TKA							{ quality = 1; price = 12500; };

	///////////////////////////////////////////////////////////////////////////////
	//CUPArmed
	///////////////////////////////////////////////////////////////////////////////
	class CUP_BAF_Jackal2_GMG_D						{ quality = 1; price = 35000; };
	class CUP_BAF_Jackal2_GMG_W						{ quality = 1; price = 35000; };
	class CUP_BAF_Jackal2_L2A1_D					{ quality = 1; price = 30000; };
	class CUP_BAF_Jackal2_L2A1_W					{ quality = 1; price = 30000; };
	class CUP_B_BAF_Coyote_L2A1_D					{ quality = 1; price = 35000; };
	class CUP_B_BAF_Coyote_L2A1_W					{ quality = 1; price = 35000; };
	class CUP_B_BRDM2_CDF							{ quality = 1; price = 23000; };
	class CUP_B_BRDM2_HQ_CDF						{ quality = 1; price = 20000; };
	class CUP_B_Dingo_GER_Wdl						{ quality = 1; price = 40000; };
	class CUP_B_FV432_Bulldog_GB_W_RWS				{ quality = 1; price = 65000; };
	class CUP_B_HMMWV_AGS_GPK_ACR					{ quality = 1; price = 29500; };
	class CUP_B_HMMWV_Crows_M2_USA					{ quality = 1; price = 25000; };
	class CUP_B_HMMWV_Crows_MK19_USA				{ quality = 1; price = 29500; };
	class CUP_B_HMMWV_DSHKM_GPK_ACR					{ quality = 1; price = 26500; };
	class CUP_B_HMMWV_M1114_USMC					{ quality = 1; price = 25000; };
	class CUP_B_HMMWV_M2_GPK_USA					{ quality = 1; price = 26500; };
	class CUP_B_HMMWV_M2_USA						{ quality = 1; price = 26500; };
	class CUP_B_HMMWV_M2_USMC						{ quality = 1; price = 25000; };
	class CUP_B_HMMWV_MK19_USA						{ quality = 1; price = 29500; };
	class CUP_B_HMMWV_MK19_USMC						{ quality = 1; price = 29500; };
	class CUP_B_HMMWV_SOV_USA						{ quality = 1; price = 28500; };
	class CUP_B_LAV25M240_USMC						{ quality = 1; price = 950000; };
	class CUP_B_LAV25_HQ_USMC						{ quality = 1; price = 450000; };
	class CUP_B_LAV25_USMC							{ quality = 1; price = 900000; };
	class CUP_B_LR_MG_CZ_W							{ quality = 1; price = 24500; };
	class CUP_B_LR_MG_GB_W							{ quality = 1; price = 24500; };
	class CUP_B_LR_Special_CZ_W						{ quality = 1; price = 28500; };
	class CUP_B_LR_Special_Des_CZ_D					{ quality = 1; price = 28500; };
	class CUP_B_Mastiff_HMG_GB_W					{ quality = 1; price = 55000; };
	class CUP_B_Ridgback_HMG_GB_W					{ quality = 1; price = 45000; };
	class CUP_B_UAZ_AGS30_CDF						{ quality = 1; price = 26500; };
	class CUP_B_UAZ_MG_ACR							{ quality = 1; price = 22500; };
	class CUP_B_UAZ_MG_CDF							{ quality = 1; price = 22500; };
	class CUP_I_BRDM2_HQ_NAPA						{ quality = 1; price = 20000; };
	class CUP_I_BRDM2_HQ_TK_Gue						{ quality = 1; price = 20000; };
	class CUP_I_BRDM2_HQ_UN							{ quality = 1; price = 20000; };
	class CUP_I_BRDM2_NAPA							{ quality = 1; price = 23000; };
	class CUP_I_BRDM2_TK_Gue						{ quality = 1; price = 23000; };
	class CUP_I_BRDM2_UN							{ quality = 1; price = 23000; };
	class CUP_I_Datsun_PK							{ quality = 1; price = 20500; };
	class CUP_I_Datsun_PK_Random					{ quality = 1; price = 20500; };
	class CUP_I_Datsun_PK_TK						{ quality = 1; price = 20500; };
	class CUP_I_Datsun_PK_TK_Random					{ quality = 1; price = 20500; };
	class CUP_I_M113_RACS							{ quality = 1; price = 35500; };
	class CUP_I_M113_UN								{ quality = 1; price = 35500; };
	class CUP_I_UAZ_AGS30_UN						{ quality = 1; price = 26500; };
	class CUP_I_UAZ_MG_UN							{ quality = 1; price = 22500; };
	class CUP_O_BRDM2_CHDKZ							{ quality = 1; price = 23000; };
	class CUP_O_BRDM2_HQ_CHDKZ						{ quality = 1; price = 20000; };
	class CUP_O_BRDM2_HQ_SLA						{ quality = 1; price = 20000; };
	class CUP_O_BRDM2_HQ_TKA						{ quality = 1; price = 20000; };
	class CUP_O_BRDM2_SLA							{ quality = 1; price = 23000; };
	class CUP_O_BRDM2_TKA							{ quality = 1; price = 23000; };
	class CUP_O_BTR90_HQ_RU							{ quality = 1; price = 450000; };
	class CUP_O_BTR90_RU							{ quality = 1; price = 1000000; };
	class CUP_O_Datsun_PK							{ quality = 1; price = 20500; };
	class CUP_O_Datsun_PK_Random					{ quality = 1; price = 20500; };
	class CUP_O_GAZ_Vodnik_PK_RU					{ quality = 1; price = 45000; };
	class CUP_O_LR_MG_TKA							{ quality = 1; price = 25000; };
	class CUP_O_LR_MG_TKM							{ quality = 1; price = 25000; };
	class CUP_O_UAZ_AGS30_CHDKZ						{ quality = 1; price = 26500; };
	class CUP_O_UAZ_AGS30_RU						{ quality = 1; price = 26500; };
	class CUP_O_UAZ_AGS30_TKA						{ quality = 1; price = 26500; };
	class CUP_O_UAZ_MG_CHDKZ						{ quality = 1; price = 22500; };
	class CUP_O_UAZ_MG_RU							{ quality = 1; price = 22500; };
	class CUP_O_UAZ_MG_TKA							{ quality = 1; price = 22500; };
	class CUP_I_SUV_Armored_ION						{ quality = 1; price = 35000; };

	///////////////////////////////////////////////////////////////////////////////
	//CUPHelis
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_AH1Z_NoWeapons						{ quality = 1; price = 175000; };
	class CUP_B_AH6J_ESCORT_USA						{ quality = 1; price = 100000; };
	class CUP_B_AW159_Unarmed_BAF					{ quality = 1; price = 30000; };
	class CUP_B_CH47F_GB							{ quality = 1; price = 40000; };
	class CUP_B_CH47F_USA							{ quality = 1; price = 40000; };
	class CUP_B_CH53E_GER							{ quality = 1; price = 57500; };
	class CUP_B_CH53E_USMC							{ quality = 1; price = 57500; };
	class CUP_B_CH53E_VIV_GER						{ quality = 1; price = 57500; };
	class CUP_B_MH60S_FFV_USMC						{ quality = 1; price = 50000; };
	class CUP_B_MH60S_USMC							{ quality = 1; price = 50000; };
	class CUP_B_MH6J_USA							{ quality = 1; price = 17000; };
	class CUP_B_MI6A_CDF							{ quality = 1; price = 175000; };
	class CUP_B_Mi171Sh_Unarmed_ACR					{ quality = 1; price = 30000; };
	class CUP_B_Mi17_CDF							{ quality = 1; price = 40000; };
	class CUP_B_Mi17_medevac_CDF					{ quality = 1; price = 30000; };
	class CUP_B_UH1Y_MEV_F							{ quality = 1; price = 30000; };
	class CUP_B_UH1Y_UNA_F							{ quality = 1; price = 30000; };
	class CUP_B_UH60L_FFV_US						{ quality = 1; price = 60000; };
	class CUP_B_UH60L_US							{ quality = 1; price = 60000; };
	class CUP_B_UH60L_Unarmed_FFV_MEV_US			{ quality = 1; price = 30000; };
	class CUP_B_UH60L_Unarmed_FFV_US				{ quality = 1; price = 30000; };
	class CUP_B_UH60L_Unarmed_US					{ quality = 1; price = 30000; };
	class CUP_B_UH60M_FFV_US						{ quality = 1; price = 60000; };
	class CUP_B_UH60M_US							{ quality = 1; price = 60000; };
	class CUP_B_UH60M_Unarmed_FFV_MEV_US			{ quality = 1; price = 30000; };
	class CUP_B_UH60M_Unarmed_FFV_US				{ quality = 1; price = 30000; };
	class CUP_B_UH60M_Unarmed_US					{ quality = 1; price = 30000; };
	class CUP_C_Mi17_Civilian_RU					{ quality = 1; price = 30000; };
	class CUP_I_UH60L_FFV_RACS						{ quality = 1; price = 60000; };
	class CUP_I_UH60L_RACS							{ quality = 1; price = 60000; };
	class CUP_I_UH60L_Unarmed_FFV_MEV_Racs			{ quality = 1; price = 30000; };
	class CUP_I_UH60L_Unarmed_FFV_Racs				{ quality = 1; price = 30000; };
	class CUP_I_UH60L_Unarmed_RACS					{ quality = 1; price = 30000; };
	class CUP_Merlin_HC3							{ quality = 1; price = 30000; };
	class CUP_Merlin_HC3_FFV						{ quality = 1; price = 30000; };
	class CUP_Merlin_HC3_MED						{ quality = 1; price = 30000; };
	class CUP_O_Mi17_TK								{ quality = 1; price = 40000; };
	class CUP_O_Mi8_medevac_CHDKZ					{ quality = 1; price = 30000; };
	class CUP_O_Mi8_medevac_RU						{ quality = 1; price = 30000; };
	class CUP_I_BTR40_TKG							{ quality = 1; price = 28500;sellprice = 11500; };

	///////////////////////////////////////////////////////////////////////////////
	//CUPPlanes
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_GR9_CAP_GB							{ quality = 1; price = 550000; };
	class CUP_B_GR9_Mk82_GB							{ quality = 1; price = 550000; };
	class CUP_B_GR9_GBU12_GB						{ quality = 1; price = 550000; };
	class CUP_B_GR9_AGM_GB							{ quality = 1; price = 550000; };
	class CUP_B_A10_CAS_USA							{ quality = 1; price = 550000; };
	class CUP_B_A10_AT_USA							{ quality = 1; price = 550000; };
	class CUP_C_AN2_AEROSCHROT_TK_CIV				{ quality = 1; price = 10000; };
	class CUP_C_AN2_CIV								{ quality = 1; price = 10000; };
	class CUP_C_AN2_AIRTAK_TK_CIV					{ quality = 1; price = 10000; };
	class CUP_O_AN2_TK								{ quality = 1; price = 10000; };
	class CUP_B_AV8B_CAP_USMC						{ quality = 1; price = 490000; };
	class CUP_I_AV8B_CAP_AAF						{ quality = 1; price = 490000; };
	class CUP_B_AV8B_MK82_USMC						{ quality = 1; price = 490000; };
	class CUP_I_AV8B_MK82_AAF						{ quality = 1; price = 490000; };
	class CUP_B_AV8B_GBU12_USMC						{ quality = 1; price = 490000; };
	class CUP_I_AV8B_GBU12_AAF						{ quality = 1; price = 490000; };
	class CUP_B_AV8B_AGM_USMC						{ quality = 1; price = 490000; };
	class CUP_I_AV8B_AGM_AAF						{ quality = 1; price = 490000; };
	class CUP_B_C130J_USMC							{ quality = 1; price = 60000; };
	class CUP_B_C130J_GB							{ quality = 1; price = 60000; };
	class CUP_I_C130J_AAF							{ quality = 1; price = 60000; };
	class CUP_I_C130J_RACS							{ quality = 1; price = 60000; };
	class CUP_O_C130J_TKA							{ quality = 1; price = 60000; };
	class CUP_B_C130J_Cargo_USMC					{ quality = 1; price = 60000; };
	class CUP_B_C130J_Cargo_GB						{ quality = 1; price = 60000; };
	class CUP_I_C130J_Cargo_AAF						{ quality = 1; price = 60000; };
	class CUP_I_C130J_Cargo_RACS					{ quality = 1; price = 60000; };
	class CUP_O_C130J_Cargo_TKA						{ quality = 1; price = 60000; };
	class CUP_C_C47_CIV								{ quality = 1; price = 15000; };
	class CUP_C_DC3_CIV								{ quality = 1; price = 15000; };
	class CUP_B_F35B_AA_USMC						{ quality = 1; price = 550000; };
	class CUP_B_F35B_CAS_USMC						{ quality = 1; price = 550000; };
	class CUP_B_F35B_LGB_USMC						{ quality = 1; price = 550000; };
	class CUP_B_F35B_AA_BAF							{ quality = 1; price = 550000; };
	class CUP_B_F35B_CAS_BAF						{ quality = 1; price = 550000; };
	class CUP_B_F35B_LGB_BAF						{ quality = 1; price = 550000; };
	class CUP_B_MV22_USMC							{ quality = 1; price = 150000; };
	class CUP_B_MV22_USMC_RAMPGUN					{ quality = 1; price = 160000; };
	class CUP_B_Su25_CDF							{ quality = 1; price = 150000; };
	class CUP_O_Su25_TKA							{ quality = 1; price = 150000; };
	class CUP_O_Su25_SLA							{ quality = 1; price = 150000; };
	class CUP_O_Su25_RU_1							{ quality = 1; price = 150000; };
	class CUP_O_Su25_RU_2							{ quality = 1; price = 150000; };
	class CUP_O_Su25_RU_3							{ quality = 1; price = 150000; };
	class CUP_O_SU34_LGB_RU							{ quality = 1; price = 550000; };
	class CUP_O_SU34_AGM_RU							{ quality = 1; price = 550000; };
	class CUP_O_SU34_LGB_SLA						{ quality = 1; price = 550000; };
	class CUP_O_SU34_AGM_SLA						{ quality = 1; price = 550000; };
	class CUP_I_SU34_LGB_AAF						{ quality = 1; price = 550000; };
	class CUP_I_SU34_AGM_AAF						{ quality = 1; price = 550000; };
	class CUP_B_SU34_LGB_CDF						{ quality = 1; price = 550000; };
	class CUP_B_SU34_AGM_CDF						{ quality = 1; price = 550000; };

	///////////////////////////////////////////////////////////////////////////////
	//	Boats
	///////////////////////////////////////////////////////////////////////////////

	class CUP_C_Fishing_Boat_Chernarus				{ quality = 1; price = 1000; };
	class CUP_B_RHIB2Turret_USMC				{ quality = 1; price = 20000; };
	class CUP_B_RHIB_USMC				{ quality = 1; price = 20000; };
	class CUP_B_Seafox_USMC				{ quality = 1; price = 1000; };
	class CUP_B_Seafox_USV_USMC			{ quality = 1; price = 1000; };
	class CUP_B_Zodiac_USMC				{ quality = 1; price = 1000; };

	///////////////////////////////////////////////////////////////////////////////
	//	Bikes
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_M1030			{ quality = 1; price = 2000; };
	class CUP_C_TT650_CIV			{ quality = 1; price = 2000; };
	class CUP_O_TT650_CHDKZ			{ quality = 1; price = 2000; };
	class CUP_O_TT650_TKA			{ quality = 1; price = 2000; };
